import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Globe,
  MessageCircle,
  Eye,
  ArrowRight,
  Heart,
} from "lucide-react";

import { supabase } from "../services/supabase";

export default function ProjectCard({ project }) {
  const [likes, setLikes] = useState(project.likes || 0);
  const [loading, setLoading] = useState(false);

  async function handleLike(e) {
    e.preventDefault();
    e.stopPropagation();

    if (loading) return;

    setLoading(true);

    const newLikes = likes + 1;

    const { error } = await supabase
      .from("Projects")
      .update({
        likes: newLikes,
      })
      .eq("id", project.id);

    if (!error) {
      setLikes(newLikes);
    }

    setLoading(false);
  }

  return (
    <div className="group overflow-hidden rounded-3xl border border-zinc-800 bg-zinc-900 transition-all duration-300 hover:-translate-y-2 hover:border-emerald-500">

      {/* Banner */}

      <div className="relative h-44 overflow-hidden bg-zinc-800">

        {project.image ? (
          <img
            src={project.image}
            alt={project.name}
            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-zinc-500">
            No Banner
          </div>
        )}

        <div className="absolute right-4 top-4 flex gap-2">

          {project.featured && (
            <span className="rounded-full bg-yellow-500 px-3 py-1 text-xs font-bold text-black">
              ⭐ Featured
            </span>
          )}

          {project.verified && (
            <span className="rounded-full bg-emerald-500 px-3 py-1 text-xs font-bold text-black">
              ✔ Verified
            </span>
          )}

        </div>

      </div>

      {/* Content */}

      <div className="p-6">

        <div className="mb-5 flex items-center gap-4">

          {project.logo ? (
            <img
              src={project.logo}
              alt={project.name}
              className="h-16 w-16 rounded-2xl border border-zinc-700 object-cover"
            />
          ) : (
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-zinc-700 bg-zinc-800 text-xl font-bold text-white">
              {project.name?.charAt(0)}
            </div>
          )}

          <div>

            <h2 className="text-xl font-bold text-white">
              {project.name}
            </h2>

            <p className="mt-1 text-sm text-zinc-400">
              {project.category}
            </p>

            {/* Builder */}

            <Link
              to={`/builder/${encodeURIComponent(project.builder || "Unknown")}`}
              className="mt-1 inline-block text-sm font-medium text-emerald-400 transition hover:text-emerald-300 hover:underline"
            >
              {project.builder || "Unknown Builder"}
            </Link>

          </div>

        </div>

        <p className="line-clamp-3 text-sm leading-7 text-zinc-400">
          {project.description}
        </p>

        <div className="mt-6 flex flex-wrap gap-2">

          {project.tags
            ?.split(",")
            .slice(0, 3)
            .map((tag) => (
              <span
                key={tag}
                className="rounded-full bg-zinc-800 px-3 py-1 text-xs text-zinc-300"
              >
                {tag.trim()}
              </span>
            ))}

        </div>

        <div className="mt-6 flex items-center justify-between border-t border-zinc-800 pt-5">

          <div className="flex items-center gap-4 text-sm text-zinc-500">

            <div className="flex items-center gap-1">
              <Eye size={16} />
              {project.views || 0}
            </div>

            <button
              onClick={handleLike}
              disabled={loading}
              className="flex items-center gap-1 transition hover:text-red-400"
            >
              <Heart size={16} />
              {likes}
            </button>

          </div>

          <div className="flex gap-2">

            {project.website && (
              <a
                href={project.website}
                target="_blank"
                rel="noreferrer"
                className="rounded-lg bg-zinc-800 p-2 hover:bg-zinc-700"
              >
                <Globe size={16} />
              </a>
            )}

            {project.github && (
              <a
                href={project.github}
                target="_blank"
                rel="noreferrer"
                className="rounded-lg bg-zinc-800 px-3 py-2 text-xs font-bold hover:bg-zinc-700"
              >
                GH
              </a>
            )}

            {project.discord && (
              <a
                href={project.discord}
                target="_blank"
                rel="noreferrer"
                className="rounded-lg bg-zinc-800 p-2 hover:bg-zinc-700"
              >
                <MessageCircle size={16} />
              </a>
            )}

          </div>

        </div>

        <Link
          to={`/project/${project.id}`}
          className="mt-6 flex items-center justify-center gap-2 rounded-2xl bg-emerald-500 py-3 font-semibold text-black transition hover:bg-emerald-400"
        >
          View Project
          <ArrowRight size={18} />
        </Link>

      </div>

    </div>
  );
}